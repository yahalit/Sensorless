/*
 * WhoIsThisProject.h
 *
 *  Created on: May 6, 2024
 *      Author: yahal
 */

#ifndef APPLICATION_WHOISTHISPROJECT_H_
#define APPLICATION_WHOISTHISPROJECT_H_

#define THISCARD 105

#endif /* APPLICATION_WHOISTHISPROJECT_H_ */
